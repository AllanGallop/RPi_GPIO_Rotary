#__init__.py
from RPi_GPIO_Rotary import rotary
